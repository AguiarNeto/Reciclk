const http = require("http");
const https = require("https");

const token = ""; //Seu token do facebook
const phone_number_id = ""; //Seu phone number id do facebook
const verify_token = ""; //Seu verify token do facebook

const openai_api_key = ""; //Sua chave da API do OpenAI
const openai_model = "gpt-3.5-turbo"; //Modelo do OpenAI

function isWinthinBusinessHours() {
  const now = new Date();
  const hour = now.getHours();
  return hour >= 7 && hour < 18; // Horário comercial das 7h às 18h
}

function sendWhatsAppMessage(to, message) {
  const data = JSON.stringify({
    messaging_product: "whatsapp",
    to: to,
    text: { body: message },
  });

  const options = {
    hostname: "graph.facebook.com",
    path: `/18.0/${phone_number_id}/messages`,
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      "Content-Length": Buffer.byteLength(data),
    },
  };

  const req = https.request(options, (res) => {
    res.on("data", (d) => ProcessingInstruction.stdown.write(d));
  });
  req.on("error", (e) => {
    console.error(`Erro ao enviar mensagem: `, e);
  });

  req.write(data);
  req.end();
}

function enviarParaChatGPT(pergunta, callback) {
  const data = JSON.stringify({
    model: openai_model,
    messages: [
      {
        role: "system",
        content:
          "Você é um atendente virtual da Reciclk, uma start-up de gestão ambiental que conecta pessoas e empresas para redirecionar resíduos recicláveis de forma sustentável. Sua tarefa é responder perguntas sobre a empresa, seus serviços e fornecer informações úteis relacionadas à reciclagem.",
      },
      {
        role: "user",
        content: pergunta,
      },
    ],
  });

  const options = {
    hostname: "api.openai.com",
    path: "/v1/chat/completions",
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${openai_api_key}`,
      "Content-Length": data.length,
    },
  };
  const req = https.request(options, (res) => {
    let resposta = "";
    res.on("data", (chunk) => {
      resposta += chunk.toString();
    });
    res.on("end", () => {
      try {
        const parsed = JSON.parse(resposta);
        const mensagem = parsed.choiced[0].message.content;
        callback(mensagem);
      } catch (err) {
        console.error("Erro ao interpretar resposta do ChatGPT:", err);
        callback(
          "Desculpe, não consegui processar sua dúvida agora. Tente novamente mais tarde."
        );
      }
    });
  });

  res.on("error", (e) => {
    console.error("Erro ao consultar ChatGPT:", e);
    callback(
      "Desculpe, ocorreu um erro ao processar sua solicitação. Tente novamente mais tarde."
    );
  });

  req.write(data);
  req.end();
}

const server = http.createServer((req, res) => {
    if (req.method === "GET") {
        const url = new URL(req.url, `http://${req.headers.host}`);
        if (
            url.pathname === "/webhook" &&
            url.searchParams.get("hub.verify_token") === verify_token
        ) {
            res.writeHead(200, { "Content-Type": "text/plain" });
            res.end(url.searchParams.get("hub.challenge"));
        } else {
            res.writeHead(403);
            res.end("Forbidden");
        }
    } else if (req.method === "POST" && req.url === "/webhook") {
        let body = "";
        req.on("data", (chunk) => {
            body += chunk.toString();
        });

        req.on("end", () => {
            try {
                const json = JSON.parse(body);
                const message = json.entry?.[0]?.changes?.[0]?.value?.messages?.[0];

                if (message) {
                    const from = message.from;
                    const text = message.text?.body;

                    if (isWinthinBusinessHours()) {
                        enviarParaChatGPT(userText, (resposta) => {
                            sendWhatsAppMessage(from, resposta);
                        });
                    } else {
                        const msg = "Olá! Nosso atendimento funciona de 7h às 18h. Envie sua dúvida e retornaremos assim que possível. 🌱";
                        sendWhatsAppMessage(from, msg);
                    }
                }

                res.writeHead(200);
                res.end("Ok");
            } catch (err) {
                console.error("Erro ao processar JSON:", err);
                res.writeHead(500);
                res.end("Erro interno");
            }
        });
    } else {
        res.writeHead(404);
        res.end("Not Found");
    }
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Servidor WhatsApp + ChatGPT rodando em http: //localhost:${PORT}`);
});